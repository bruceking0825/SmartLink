Parallel processing is fully supported on Linux. Available features on
other platforms are limited.

| Feature                    | Linux  | MacOS  | Windows (.exe) | Windows (installer) |
 --------------------------- | ------ | ------ | -------------- | ------------------- |
| Multiple local processes   | Yes    | Yes    | No             | Yes                 |
| Run server locally         | Yes    | ?      | No             | Yes                 |
| Connect to a remote server | Yes    | ?      | No             | Yes                 |
| Mixed local and remote     | Yes    | ?      | No             | No                  |
