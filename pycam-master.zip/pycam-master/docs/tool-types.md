Tool types
==========
Pycam support three tool shapes: Flat bottom (cylindrical), ball nose (spherical), and bull nose (toroidal).
In addition to the tool shape the feedrate and spindle speed are also configured per tool.
